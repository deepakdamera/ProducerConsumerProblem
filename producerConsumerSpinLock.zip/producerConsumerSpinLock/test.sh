#!/bin/bash
for i in {1..20}
do
	./main 10 10 9 100;
	echo $?
done
